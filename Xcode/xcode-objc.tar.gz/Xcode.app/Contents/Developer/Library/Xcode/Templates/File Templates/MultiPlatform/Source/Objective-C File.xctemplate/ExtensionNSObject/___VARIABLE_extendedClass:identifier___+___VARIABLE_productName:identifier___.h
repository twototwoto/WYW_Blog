//___FILEHEADER___

___IMPORTHEADER_extendedClass___

NS_ASSUME_NONNULL_BEGIN

@interface ___VARIABLE_extendedClass:identifier___ ()

@end

NS_ASSUME_NONNULL_END
